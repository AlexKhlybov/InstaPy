> **Please Note**: The scripts for Linux and RaspberryPi still have to be added!

### Starting InstaPy

Starting InstaPy with the start scripts is as easy as double clicking the file for your system.   
A command line will open and start to run InstaPy for you.
The actions taken by InstaPy will be logged there.

> If you see any error messages, please search the [issues](https://github.com/timgrossmann/InstaPy/issues) for your error, there most likely already will be a solution to that.
