# Simple update script for Linux

echo "Updating InstaPy..."
echo "===================="
pip install -U instapy
