## How to use the templates?

It's really easy, just download one of the template files to your system and edit the username and password and adjust the lists to fit your needs. 

#### ⚠️ Caution 
Some of the follow/liking limits may not be best to use with Instagram's ever changing limits.    
**Start small and play around with these.**

###### Have fun & stay responsible
