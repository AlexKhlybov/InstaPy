import random
from instapy import InstaPy
from instapy import smart_run

file1, file2, file3 = open('logpass.txt'), open('competitors.txt'), open('hashtags.txt')
insta_username, insta_password = file1.readline().split()
competitors = [x for x in file2]
hashtags = [x for x in file3]
file1.close()
file2.close()
file3.close()

session = InstaPy(username = insta_username,
                  password = insta_password)

with smart_run(session):
    #session.set_user_interact(amount=5, randomize=True, percentage=100, media='Photo')
    #session.follow_user_followers(competitors, amount=10, randomize=False, interact=True)

    session.set_relationship_bounds(enabled = True,
                                    delimit_by_numbers = True,
                                    max_followers = 1500,
                                    min_followers = 100,
                                    min_following = 100,
                                    max_following = 700)

    session.set_quota_supervisor(enabled = True,
                            sleep_after = ['likes_h', 'comments_h', 'follows_h', 'unfollows_h', 'server_calls_h'],
                            sleepyhead = True,
                            stochastic_flow = True,
                            notify_me = True,
                            peak_likes_hourly = 40,
                            peak_likes_daily = 500,
                            peak_comments_hourly = 25,
                            peak_comments_daily = 150,
                            peak_follows_hourly = 30,
                            peak_follows_daily = 400,
                            peak_unfollows_hourly = 30,
                            peak_unfollows_daily = 400,
                            peak_server_calls_hourly = None,
                            peak_server_calls_daily = 4700)

    session.set_action_delays(enabled = True,
                           like = 15,
                           comment = 50,
                           follow = 15,
                           unfollow = 15,
                           story = 15)

    session.set_user_interact(amount = 1,
                          percentage = 100,
                          randomize = False,
                          media = 'Photo')
    #session.set_do_like(enabled = True, percentage = 100)
    session.set_do_story(enabled = True, percentage = 100, simulate = True)
    session.follow_user_followers(competitors, amount = 30,
                                  randomize = False, interact = True)

    session.unfollow_users(amount=200, instapy_followed_enabled=True, instapy_followed_param="nonfollowers",
                           style="FIFO")
